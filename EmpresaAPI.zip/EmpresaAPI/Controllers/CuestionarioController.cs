﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EmpresasAPI.Models;
using EmpresasAPI.Data;

namespace EmpresasAPI.Controllers
{
    public class CuestionarioController : ApiController
    {
        public List<Cuestionario> Get()
        {
            return DatosCuestionario.Listar();
        }
        // GET: Usuario
        public Cuestionario Get(int id)
        {
            return DatosCuestionario.Obtener(id);
        }
    }        
}
