﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EmpresasAPI.Data;
using System.Web.Http;
using EmpresasAPI.Models;

namespace EmpresasAPI.Controllers
{
    public class CompaniaController : ApiController
    {

        // GET api/<controller>
        public List<Empresa> Get()
        {
            return Datos.Listar();
        }

        // GET api/<controller>/5
        public Empresa Get(int Id_Empresa)
        {
            return Datos.Obtener(Id_Empresa);
        }
    }
}
    

