﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using EmpresasAPI.Models;
using EmpresasAPI.Data;

namespace EmpresasAPI.Controllers
{
    public class UsuarioController : ApiController
    {
        public List<Usuarios> Get()
        {
            return DatosUsuarios.Listar();
        }
        // GET: Usuario
        public Usuarios Get(int id)
        {
            return DatosUsuarios.Obtener(id);
        }
        public Usuarios Patch(int id)
        {
            return DatosUsuarios.Obtener1(id);

        }
    }
}