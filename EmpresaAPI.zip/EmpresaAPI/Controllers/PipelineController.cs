﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EmpresasAPI.Models;
using EmpresasAPI.Data;

namespace EmpresasAPI.Controllers
{
    public class PipelineController : ApiController
    {
        public List<Pipeline> Get()
        {
            return DatosPipeline.Listar();
        }
        // GET: Usuario
        public Pipeline Get(int id)
        {
            return DatosPipeline.Obtener(id);
        }
        public Pipeline Patch(int id)
        {
            return DatosPipeline.Obtener1(id);
        }

    }
}
