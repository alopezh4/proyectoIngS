﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using EmpresasAPI.Models;

namespace EmpresasAPI.Data
{
    public class DatosPipeline
    {
        public static List<Pipeline> Listar()
        {
            List<Pipeline> oListaPipeline = new List<Pipeline>();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("pipe_listar", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            oListaPipeline.Add(new Pipeline()
                            {
                                Id_Pipeline = Convert.ToInt32(dr["Id_Pipeline"]),
                                Nombre = dr["Nombre"].ToString(),   
                                Id_Empresa = Convert.ToInt32(dr["Id_Empresa"]),
                            });
                        }

                    }
                    return oListaPipeline;
                }
                catch (Exception ex)
                {
                    return oListaPipeline;
                }
            }
        }

        public static Pipeline Obtener(int idpipeline)
        {
            Pipeline oPipeline = new Pipeline();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("pipe_obtener", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id_Pipeline", idpipeline);
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            oPipeline = new Pipeline()
                            {
                                Id_Pipeline = Convert.ToInt32(dr["Id_Pipeline"]),
                                Nombre = dr["Nombre"].ToString(),
                                Id_Empresa = Convert.ToInt32(dr["Id_Empresa"]),
                            };
                        }

                    }
                    return oPipeline;
                }
                catch (Exception ex)
                {
                    return oPipeline;
                }
            }
        }

        public static Pipeline Obtener1(int idempresa)
        {
            Pipeline oPipeline = new Pipeline();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("pipe_obtener1", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id_Empresa", idempresa);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            oPipeline = new Pipeline()
                            {
                                Id_Pipeline = Convert.ToInt32(dr["Id_Pipeline"]),
                                Nombre = dr["Nombre"].ToString(),
                                Id_Empresa = Convert.ToInt32(dr["Id_Empresa"]),
                            };
                        }
                    }
                    return oPipeline;
                }
                catch (Exception ex)
                {
                    return oPipeline;
                }
            }
        }
    }
}
