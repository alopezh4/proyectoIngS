﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using EmpresasAPI.Models;

namespace EmpresasAPI.Data
{
    public class DatosUsuarios
    {
        public static List<Usuarios> Listar()
        {
            List<Usuarios> oListaUsuario = new List<Usuarios>();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("us_listar", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            oListaUsuario.Add(new Usuarios()
                            {
                                Id_Usuario = Convert.ToInt32(dr["Id_Usuario"]),
                                Usuario = dr["Usuario"].ToString(),
                                Contraseña = dr["Contraseña"].ToString(),
                                Id_Rol = Convert.ToInt32(dr["Id_Rol"]),
                                Id_Empresa = Convert.ToInt32(dr["Id_Empresa"]),
                                Descripcion = dr["Descripcion"].ToString(),
                            });
                        }

                    }
                    return oListaUsuario;
                }
                catch (Exception ex)
                {
                    return oListaUsuario;
                }
            }
        }

        public static Usuarios Obtener(int idusuario)
        {
            Usuarios oUsuario = new Usuarios();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("us_obtener", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id_Usuario", idusuario);
                try
                    {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            oUsuario = new Usuarios()
                            {
                                Id_Usuario = Convert.ToInt32(dr["Id_Usuario"]),
                                Usuario = dr["Usuario"].ToString(),
                                Contraseña = dr["Contraseña"].ToString(),
                                Id_Rol = Convert.ToInt32(dr["Id_Rol"]),
                                Id_Empresa = Convert.ToInt32(dr["Id_Empresa"]),
                                Descripcion = dr["Descripcion"].ToString(),
                            };
                        }

                    }
                    return oUsuario;
                }
                catch (Exception ex)
                {
                    return oUsuario;
                }
            }
        }

        public static Usuarios Obtener1(int idempresa)
        {
            Usuarios oUsuario = new Usuarios();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("us_obtener2", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id_Empresa", idempresa);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            oUsuario = new Usuarios()
                            {
                                Id_Usuario = Convert.ToInt32(dr["Id_Usuario"]),
                                Usuario = dr["Usuario"].ToString(),
                                Contraseña = dr["Contraseña"].ToString(),
                                Id_Rol = Convert.ToInt32(dr["Id_Rol"]),
                                Id_Empresa = Convert.ToInt32(dr["Id_Empresa"]),
                                Descripcion = dr["Descripcion"].ToString(),
                            };
                        }
                    }
                    return oUsuario;
                }
                catch (Exception ex)
                {
                    return oUsuario;
                }
            }
        }
    }
}