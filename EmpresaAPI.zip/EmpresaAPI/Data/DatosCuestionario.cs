﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using EmpresasAPI.Models;

namespace EmpresasAPI.Data
{
    public class DatosCuestionario
    {
        public static List<Cuestionario> Listar()
        {
            List<Cuestionario> oListaCuestionario = new List<Cuestionario>();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("cues_listar", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            oListaCuestionario.Add(new Cuestionario()
                            {
                                Id_Cuestionario = Convert.ToInt32(dr["Id_Cuestionario"]),
                                Titulo = dr["Titulo"].ToString(),
                                Id_Pregunta = Convert.ToInt32(dr["Id_Pregunta"]),
                                Id_Plaza = Convert.ToInt32(dr["Id_Plaza"]),
                            });
                        }

                    }
                    return oListaCuestionario;
                }
                catch (Exception ex)
                {
                    return oListaCuestionario;
                }
            }
        }

        public static Cuestionario Obtener(int idcuestionario)
        {
            Cuestionario oCuestionario = new Cuestionario();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("cues_obtener", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id_Cuestionario", idcuestionario);
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            oCuestionario = new Cuestionario()
                            {
                                Id_Cuestionario = Convert.ToInt32(dr["Id_Cuestionario"]),
                                Titulo = dr["Titulo"].ToString(),
                                Id_Pregunta = Convert.ToInt32(dr["Id_Pregunta"]),
                                Id_Plaza = Convert.ToInt32(dr["Id_Plaza"]),
                            };
                        }

                    }
                    return oCuestionario;
                }
                catch (Exception ex)
                {
                    return oCuestionario;
                }
            }
        }
        }
    }

