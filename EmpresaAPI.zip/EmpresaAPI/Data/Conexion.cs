﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmpresasAPI.Data
{
    public class Conexion
    {
        public static string rutaConexion = "Data Source=DESKTOP-C1JOR9J;Initial Catalog=BDISJOBS;Integrated Security=True";
    }
}