﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using EmpresasAPI.Models;

namespace EmpresasAPI.Data
{
    public class Datos
    {
        public static List<Empresa> Listar()
        {
            List<Empresa> oLista = new List<Empresa>();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("empresa_listar", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oLista.Add(new Empresa()
                            {
                                Id_Empresa = Convert.ToInt32(dr["Id_Empresa"]),
                                Nombre = dr["Nombre"].ToString(),
                                Correo = dr["Correo"].ToString(),
                                Telefono = dr["Telefono"].ToString(),
                                Direccion = dr["Direccion"].ToString(),
                                Descripcion = dr["Descripcion"].ToString(),
                            });
                        }

                    }
                    return oLista;
                }
                catch (Exception ex)
                {
                    return oLista;
                }
            }
        }

        public static Empresa Obtener(int Id_Empresa)
        {
            Empresa oEmpresa = new Empresa();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("empresa_obtener", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id_Empresa", Id_Empresa);
                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            oEmpresa = new Empresa()
                            {
                                Id_Empresa = Convert.ToInt32(dr["Id_Empresa"]),
                                Nombre = dr["Nombre"].ToString(),
                                Correo = dr["Correo"].ToString(),
                                Telefono = dr["Telefono"].ToString(),
                                Direccion = dr["Direccion"].ToString(),
                                Descripcion = dr["Descripcion"].ToString(),
                            };
                        }

                    }
                    return oEmpresa;
                }
                catch (Exception ex)
                {
                    return oEmpresa;
                }
            }
        }
       
    }
}
