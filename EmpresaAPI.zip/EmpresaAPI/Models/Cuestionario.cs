﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmpresasAPI.Models
{
    public class Cuestionario
    {
        public int Id_Cuestionario { get; set; }
        public string Titulo { get; set; }
        public int Id_Pregunta { get; set; }
        public int Id_Plaza { get; set; }
    }
}