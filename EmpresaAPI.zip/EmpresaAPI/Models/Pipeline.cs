﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmpresasAPI.Models
{
    public class Pipeline
    {
        public int Id_Pipeline { get; set; }
        public string Nombre { get; set; }
        public int Id_Empresa { get; set; }
    }
}