﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PosicionWebApi.Models
{
    public class Posicion
    {
        public int Id_Plaza { get; set; }
        public string Nombre { get; set; }

        public string Descripcion { get; set; }
        public int Id_Empresa { get; set; }
        public int Id_Departamento { get; set; }
        public int Id_Pais { get; set; }
        public int Id_Categoria { get; set; }

        public int Id_Jornada { get; set; }

        public int Id_Educacion { get; set; }
        public int Id_Experiencia { get; set; }
        public int Salario { get; set; }

        public int Id_Estado { get; set; }
    }
}