﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using PosicionWebApi.Data;
using PosicionWebApi.Models;

namespace PosicionWebApi.Controllers
{
    public class PosicionController : ApiController
    {
        // GET api/<controller>
        public List<Posicion> Get()
        {
            return PlazasData.Listar();
        }

        // GET api/<controller>/5
        public Posicion Get(int id)
        {
            return PlazasData.Obtener(id);
        }

        // PATCH api/<controller>/5
        public Posicion PATCH(int id)
        {
            return PlazasData.Obtener1(id);
        }



        // POST api/<controller>
        public bool Post([FromBody] Posicion oPosicion)
        {
            return PlazasData.Registrar(oPosicion);
        }

        // PUT api/<controller>/5
        public bool Put([FromBody] Posicion oPosicion)
        {
            return PlazasData.Modificar(oPosicion);
        }

        // DELETE api/<controller>/5
        public bool Delete(int id)
        {
            return PlazasData.Eliminar(id);
        }
    }
}