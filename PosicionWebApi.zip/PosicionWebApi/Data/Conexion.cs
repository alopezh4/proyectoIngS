﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PosicionWebApi.Data
{
    public class Conexion
    {
        public static string rutaConexion = "Data Source=LAPTOP-IQELK4J0;Initial Catalog=BDISJOBS;Integrated Security=True";
    }
}