﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using PosicionWebApi.Models;

namespace PosicionWebApi.Data
{
    public class PlazasData
    {
        public static bool Registrar(Posicion oPosicion)
        {
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("usp_registrar", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Nombre", oPosicion.Nombre);
                cmd.Parameters.AddWithValue("@Descripcion", oPosicion.Descripcion);
                cmd.Parameters.AddWithValue("@Id_Empresa", oPosicion.Id_Empresa);
                cmd.Parameters.AddWithValue("@Id_Departamento", oPosicion.Id_Departamento);
                cmd.Parameters.AddWithValue("@Id_Pais", oPosicion.Id_Pais);
                cmd.Parameters.AddWithValue("@Id_Categoria", oPosicion.Id_Categoria);
                cmd.Parameters.AddWithValue("@Id_Jornada", oPosicion.Id_Jornada);
                cmd.Parameters.AddWithValue("@Id_Educacion", oPosicion.Id_Educacion);
                cmd.Parameters.AddWithValue("@Id_Experiencia", oPosicion.Id_Experiencia);
                cmd.Parameters.AddWithValue("@Salario", oPosicion.Salario);
                cmd.Parameters.AddWithValue("@Id_Estado", oPosicion.Id_Estado);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
        }

        public static bool Modificar(Posicion oPosicion)
        {
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("usp_modificar", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id_Plaza", oPosicion.Id_Plaza);
                cmd.Parameters.AddWithValue("@Nombre", oPosicion.Nombre);
                cmd.Parameters.AddWithValue("@Descripcion", oPosicion.Descripcion);
                cmd.Parameters.AddWithValue("@Id_Empresa", oPosicion.Id_Empresa);
                cmd.Parameters.AddWithValue("@Id_Departamento", oPosicion.Id_Departamento);
                cmd.Parameters.AddWithValue("@Id_Pais", oPosicion.Id_Pais);
                cmd.Parameters.AddWithValue("@Id_Categoria", oPosicion.Id_Categoria);
                cmd.Parameters.AddWithValue("@Id_Jornada", oPosicion.Id_Jornada);
                cmd.Parameters.AddWithValue("@Id_Educacion", oPosicion.Id_Educacion);
                cmd.Parameters.AddWithValue("@Id_Experiencia", oPosicion.Id_Experiencia);
                cmd.Parameters.AddWithValue("@Salario", oPosicion.Salario);
                cmd.Parameters.AddWithValue("@Id_Estado", oPosicion.Id_Estado);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
        }

        public static List<Posicion> Listar()
        {
            List<Posicion> oListaPosicion = new List<Posicion>();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("usp_listar", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            oListaPosicion.Add(new Posicion()
                            {
                                Id_Plaza = Convert.ToInt32(dr["Id_Plaza"]),
                                Nombre = dr["Nombre"].ToString(),
                                Descripcion = dr["Descripcion"].ToString(),
                                Id_Empresa = Convert.ToInt32(dr["Id_Empresa"]),
                                Id_Departamento = Convert.ToInt32(dr["Id_Departamento"]),
                                Id_Pais = Convert.ToInt32(dr["Id_Pais"]),
                                Id_Categoria = Convert.ToInt32(dr["Id_Categoria"]),
                                Id_Jornada = Convert.ToInt32(dr["Id_Jornada"]),
                                Id_Educacion = Convert.ToInt32(dr["Id_Educacion"]),
                                Id_Experiencia = Convert.ToInt32(dr["Id_Experiencia"]),
                                Salario = Convert.ToInt32(dr["Salario"]),
                                Id_Estado = Convert.ToInt32(dr["Id_Estado"])
                            });
                        }

                    }



                    return oListaPosicion;
                }
                catch (Exception ex)
                {
                    return oListaPosicion;
                }
            }
        }

        public static Posicion Obtener(int idplaza)
        {
            Posicion oPosicion = new Posicion();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("usp_obtener", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id_Plaza", idplaza);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            oPosicion = new Posicion()
                            {
                                Id_Plaza = Convert.ToInt32(dr["Id_Plaza"]),
                                Nombre = dr["Nombre"].ToString(),
                                Descripcion = dr["Descripcion"].ToString(),
                                Id_Empresa = Convert.ToInt32(dr["Id_Empresa"]),
                                Id_Departamento = Convert.ToInt32(dr["Id_Departamento"]),
                                Id_Pais = Convert.ToInt32(dr["Id_Pais"]),
                                Id_Categoria = Convert.ToInt32(dr["Id_Categoria"]),
                                Id_Jornada = Convert.ToInt32(dr["Id_Jornada"]),
                                Id_Educacion = Convert.ToInt32(dr["Id_Educacion"]),
                                Id_Experiencia = Convert.ToInt32(dr["Id_Experiencia"]),
                                Salario = Convert.ToInt32(dr["Salario"]),
                                Id_Estado = Convert.ToInt32(dr["Id_Estado"])
                            };
                        }

                    }



                    return oPosicion;
                }
                catch (Exception ex)
                {
                    return oPosicion;
                }
            }
        }

        public static Posicion Obtener1(int idestado)
        {
            Posicion oPosicion = new Posicion();
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("usp_obtener1", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id_Estado", idestado);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {

                        while (dr.Read())
                        {
                            oPosicion = new Posicion()
                            {
                                Id_Plaza = Convert.ToInt32(dr["Id_Plaza"]),
                                Nombre = dr["Nombre"].ToString(),
                                Descripcion = dr["Descripcion"].ToString(),
                                Id_Empresa = Convert.ToInt32(dr["Id_Empresa"]),
                                Id_Departamento = Convert.ToInt32(dr["Id_Departamento"]),
                                Id_Pais = Convert.ToInt32(dr["Id_Pais"]),
                                Id_Categoria = Convert.ToInt32(dr["Id_Categoria"]),
                                Id_Jornada = Convert.ToInt32(dr["Id_Jornada"]),
                                Id_Educacion = Convert.ToInt32(dr["Id_Educacion"]),
                                Id_Experiencia = Convert.ToInt32(dr["Id_Experiencia"]),
                                Salario = Convert.ToInt32(dr["Salario"]),
                                Id_Estado = Convert.ToInt32(dr["Id_Estado"])
                            };
                        }

                    }



                    return oPosicion;
                }
                catch (Exception ex)
                {
                    return oPosicion;
                }
            }
        }



        public static bool Eliminar(int id)
        {
            using (SqlConnection oConexion = new SqlConnection(Conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("usp_eliminar", oConexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("Id_Plaza", id);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
        }
    }
}