﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoF2_Astrid.Models
{
    public class MPipeline
    {
        public int Id_Postulado { get; set; }
        public int Id_Pipeline { get; set; }
    }
}