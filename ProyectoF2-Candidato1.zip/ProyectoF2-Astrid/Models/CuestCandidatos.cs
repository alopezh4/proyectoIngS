﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoF2_Astrid.Models
{
    public class CuestCandidatos
    {
        public string NombreC { get; set; }
        public string PreguntaC { get; set; }
        public string RespuestaC { get; set; }
    }
}