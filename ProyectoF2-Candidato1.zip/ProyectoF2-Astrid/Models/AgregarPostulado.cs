﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoF2_Astrid.Models
{
    public class AgregarPostulado
    {
        public int Id_Candidato { get; set; }
        public int Id_Plaza { get; set; }
        public int Id_Pipeline { get; set; }
    }
}