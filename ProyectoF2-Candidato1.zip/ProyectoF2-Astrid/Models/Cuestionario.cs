﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoF2_Astrid.Models
{
    public class Cuestionario
    {
        public string Titulo { get; set; }
        public int Id_Pregunta { get; set; }
        public int Id_Plaza { get; set; }
    }
}