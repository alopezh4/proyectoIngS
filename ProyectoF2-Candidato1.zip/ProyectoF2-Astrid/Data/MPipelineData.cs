﻿using ProyectoF2_Astrid.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;

namespace ProyectoF2_Astrid.Data
{
    public class MPipelineData
    {
        public static bool Modificaretapa(MPipeline oMovP)
        {
            using (SqlConnection oConexion = new SqlConnection(ConexionBD.rutaConexion))
            {
                SqlCommand cmd2 = new SqlCommand("usp_movestados", oConexion);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@idpostulado", oMovP.Id_Postulado);
                cmd2.Parameters.AddWithValue("@idpipeline", oMovP.Id_Pipeline);

                try
                {
                    oConexion.Open();
                    cmd2.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
        }
    }
}