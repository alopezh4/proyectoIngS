﻿using ProyectoF2_Astrid.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;

namespace ProyectoF2_Astrid.Data
{
    public class MoverPuestoData
    {
        public static bool ModificarPuesto(MoverPuesto oMP)
        {
            using (SqlConnection oConexion = new SqlConnection(ConexionBD.rutaConexion))
            {
                SqlCommand cmd2 = new SqlCommand("usp_movpuesto", oConexion);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@idcandidato", oMP.Id_Candidato);
                cmd2.Parameters.AddWithValue("@idplaza", oMP.Id_Plaza);

                try
                {
                    oConexion.Open();
                    cmd2.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
        }
    }
}