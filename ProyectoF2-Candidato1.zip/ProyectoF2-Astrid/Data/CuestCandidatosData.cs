﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ProyectoF2_Astrid.Models;
using System.Data.SqlClient;
using System.Data;

namespace ProyectoF2_Astrid.Data
{
    public class CuestCandidatosData
    {
        public static List<CuestCandidatos> ListarC()
        {
            List<CuestCandidatos> oListaCCandidatos = new List<CuestCandidatos>();
            using (SqlConnection oConexion = new SqlConnection(ConexionBD.rutaConexion))
            {
                SqlCommand cmd1 = new SqlCommand("usp_cuestionariosc", oConexion);
                cmd1.CommandType = CommandType.StoredProcedure;

                try
                {
                    oConexion.Open();
                    cmd1.ExecuteNonQuery();

                    using (SqlDataReader dr1 = cmd1.ExecuteReader())
                    {
                        while (dr1.Read())
                        {
                            oListaCCandidatos.Add(new CuestCandidatos()
                            {
                                NombreC = dr1["Nombre"].ToString(),
                                PreguntaC = dr1["Pregunta"].ToString(),
                                RespuestaC = dr1["Respuesta"].ToString()
                               
                            });
                        }
                    }
                    return oListaCCandidatos;
                }
                catch (Exception ex)
                {
                    return oListaCCandidatos;
                }
            }
        }
    }
}