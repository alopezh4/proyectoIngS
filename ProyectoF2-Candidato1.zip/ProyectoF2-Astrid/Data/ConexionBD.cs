﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProyectoF2_Astrid.Data
{
    public class ConexionBD
    {
        public static string rutaConexion = "Data Source=DESKTOP-UQOQOND;Initial Catalog=BDISJOBS;Integrated Security=True";
    }
}