﻿using ProyectoF2_Astrid.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ProyectoF2_Astrid.Data
{
    public class AgregarPostuladoData
    {
        public static bool GuardarPostulado(AgregarPostulado oAPostulado)
        {
            using (SqlConnection oConexion = new SqlConnection(ConexionBD.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("usp_addpostulado", oConexion);

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idcandidato", oAPostulado.Id_Candidato);
                cmd.Parameters.AddWithValue("@idplaza", oAPostulado.Id_Plaza);
                cmd.Parameters.AddWithValue("@idpipeline", oAPostulado.Id_Pipeline);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
        }
    }
}