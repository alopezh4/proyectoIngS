﻿using ProyectoF2_Astrid.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ProyectoF2_Astrid.Data
{
    public class CuestionarioData
    {
        public static bool GuardarCuestionario(Cuestionario oCuestionario)
        {
            using (SqlConnection oConexion = new SqlConnection(ConexionBD.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("usp_crearcuestionario", oConexion);
                
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@titulo", oCuestionario.Titulo);
                cmd.Parameters.AddWithValue("@idpregunta", oCuestionario.Id_Pregunta);
                cmd.Parameters.AddWithValue("@idplaza", oCuestionario.Id_Plaza);

                try
                {
                    oConexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }
            }
        }
    }
}