﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IS_proyecto.Models
{
    public class Candidato
    {
        public int id_candidato { get; set; }
        public string nombre { get; set; }
        public string correo { get; set; }
        public string telefono { get; set; }
        public string direccion { get; set; }
        public string curriculum { get; set; }
        public string descripcion { get; set; }
        public int id_educacion { get; set; }
    }
}