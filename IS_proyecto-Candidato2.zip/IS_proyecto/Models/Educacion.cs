﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IS_proyecto.Models
{
    public class Educacion
    {
        public int ideducacion { get; set; }
        public string educacion { get; set; }
    }
}