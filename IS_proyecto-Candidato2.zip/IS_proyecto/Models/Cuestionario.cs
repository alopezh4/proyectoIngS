﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IS_proyecto.Models
{
    public class Cuestionario
    {
        public int idcuestionario { get; set; }
        public string titulo { get; set; }
        public int idpregunta { get; set; }
        public int idplaza { get; set; }
    }
}