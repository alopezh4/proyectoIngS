﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IS_proyecto.Models
{
    public class Pregunta
    {
        public int idpregunta { get; set; }
        public string pregunta { get; set; }
        public int idprespueta { get; set; }
    }
}