﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IS_proyecto.Models
{
    public class Respuesta
    {
        public int idprespueta { get; set; }
        public string respuesta { get; set; }
        
    }
}