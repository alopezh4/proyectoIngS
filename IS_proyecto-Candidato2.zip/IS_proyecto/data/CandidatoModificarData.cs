﻿using IS_proyecto.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace IS_proyecto.data
{
    public class CandidatoModificarData
    {
        public static bool Modificar(CandidatoModificar ocandidato)
        {
            using (SqlConnection oconexion = new SqlConnection(conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("m_cand", oconexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id_candidato", ocandidato.id_candidato);
                cmd.Parameters.AddWithValue("@nombre", ocandidato.nombre);
                cmd.Parameters.AddWithValue("@correo", ocandidato.correo);
                cmd.Parameters.AddWithValue("@telefono", ocandidato.telefono);
                cmd.Parameters.AddWithValue("@direccion", ocandidato.direccion);
                cmd.Parameters.AddWithValue("@descripcion", ocandidato.descripcion);
                try
                {
                    oconexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }

            }
        }
    }
}