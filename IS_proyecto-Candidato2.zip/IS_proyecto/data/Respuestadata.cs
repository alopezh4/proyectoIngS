﻿using IS_proyecto.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace IS_proyecto.data
{
    public class Respuestadata
    {
        
       
        public static bool Reg_Respuesta(Respuesta orespuesta)
        {
            using (SqlConnection oconexion = new SqlConnection(conexion.rutaConexion)) 
            {
                SqlCommand cmd = new SqlCommand("ag_respuesta", oconexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Respuesta", orespuesta.respuesta);
                try
                {
                    oconexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch(Exception ex)
                {
                    return false;
                }
                
            }
        }
    }
}