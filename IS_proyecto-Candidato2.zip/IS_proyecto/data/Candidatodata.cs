﻿using IS_proyecto.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace IS_proyecto.data
{
    public class Candidatodata
    {
        private static Candidato ocandidato;
        public static Candidato Buscar(int idcandidato)
        {
            using (SqlConnection oconexion = new SqlConnection(conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("fnd_candidato", oconexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idcandidato",idcandidato);
                try
                {
                    oconexion.Open();
                    cmd.ExecuteNonQuery();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            ocandidato = new Candidato()
                            {
                                id_candidato = Convert.ToInt32(dr["Id_candidato"]),
                                nombre = dr["Nombre"].ToString(),
                                correo = dr["Correo"].ToString(),
                                telefono = dr["Telefono"].ToString(),
                                direccion = dr["Direccion"].ToString(),
                                descripcion = dr["Descripcion"].ToString(),
                                curriculum = dr["Curriculum"].ToString(),
                                id_educacion = Convert.ToInt32(dr["Id_educacion"]),
                            };
                        }
                    }
                    return ocandidato;
                }
                catch(Exception ex)
                {
                    return ocandidato;
                }


            }
        }
        public static bool reg_educacion(Candidato ocandidato)
        {
            using (SqlConnection oconexion = new SqlConnection(conexion.rutaConexion))
            {
                SqlCommand cmd = new SqlCommand("m_educacion", oconexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id_candidato", ocandidato.id_candidato);
                cmd.Parameters.AddWithValue("@id_educacion", ocandidato.id_educacion);
                try
                {
                    oconexion.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    return false;
                }

            }
        }
    }
}