﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IS_proyecto.data
{
    public class conexion
    {
        public static string rutaConexion = "Data Source=DESKTOP-UQOQOND;Initial Catalog=BDISJOBS;Integrated Security=True";
    }
}