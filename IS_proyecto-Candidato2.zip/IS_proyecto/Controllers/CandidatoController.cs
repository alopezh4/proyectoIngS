﻿using IS_proyecto.data;
using IS_proyecto.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace IS_proyecto.Controllers
{
    public class CandidatoController : ApiController
    {
        // GET api/<controller>/5
        public Candidato Get(int id)
        {
            return Candidatodata.Buscar(id);
        }

        // POST api/<controller>


        // PUT api/<controller>/5
        public bool Put([FromBody] Candidato candidato)
        {
            return Candidatodata.reg_educacion(candidato);
        }
    }
}